# Better Software Assessment - Frontend

## Features

- React component to Add and Display Comments
- Axios for API calls

## Usage

Import `Comments` component into any page and pass `taskId` as prop.
